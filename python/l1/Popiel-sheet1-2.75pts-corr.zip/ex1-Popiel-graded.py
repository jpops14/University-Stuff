from decimal import *

getcontext().prec = 25

def vat_faktura(lista):
    suma_cen=sum(lista)
    vat=0.23*suma_cen
    print(vat)
    return vat

def vat_paragon(lista):
	lista_podatkow=[cena * 0.23 for cena in lista]
	vat = sum(lista_podatkow)
	print(vat)
	return vat
	
	
	
def decimal_vat_faktura(lista):
    sumprice=Decimal(0.0)
    for x in lista:
        sumprice=Decimal(sumprice)+Decimal(x)
    vat=Decimal(0.23)*Decimal(sumprice)
    print(vat)
    return vat

def decimal_vat_paragon(lista):
	vat=Decimal(0.0)
	for x in lista:
	    vat=Decimal(vat)+Decimal(x)*Decimal(0.23)
	print(vat)    
	return vat	
	

zakupy = [0.2, 0.5, 4.59, 6]
print(vat_faktura(zakupy) == vat_paragon(zakupy))
print(decimal_vat_faktura(zakupy) == decimal_vat_paragon(zakupy))

# Grade: 0.5

# Didactic notes:
# First of all, there should be more comments, there are none here. I understand the code is fairly simple, but
# whenever there is an experiment or generally any exercise with a simple solution, it is expected that the testing
# and the explanations are non-trivial, so that it sums up to one reasonable effort.

# So for next time, much more testing should be present, not only the one sample in the exercise sheet.

# Next:

print(decimal_vat_faktura(zakupy))

# Aren't you surprised that even using the Decimal class, you get a really strange number, namely
# 2.596700000000000082678308 ?

# Aren't you surprised that your Decimal solution has so many decimal places, if the input is just simple numbers
# with only two decimal digits? You really should have commented on this phenomenon, because it *seems* wrong and
# indeed *is* wrong, due to your use of Decimal(0.23) instead of the correct Decimal("0.23"), and converting
# the input invoice incorrectly, too.

# Due to this, it is not even making correct Decimal computations, and I cannot accept it even as a minimal solution.
