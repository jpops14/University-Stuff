import string

def is_palindrome(text):
    normalized=(text.translate(str.maketrans('', '', string.punctuation))).replace(" ","").lower()
    reversed=normalized[::-1]
    return (reversed==normalized)
    
print (is_palindrome("Kobyła ma mały bok."))
print (is_palindrome("Eine güldne, gute Tugend: Lüge nie!"))
print (is_palindrome("not a palindrome"))

# Grade: 0.5

# Didactical notes:
print(is_palindrome("¿Palinnilap?")) # Should be true, as it contains a palindrome plus very common European punctuation
# marks.
# Using string.punctuation is simply not correct for Unicode texts, you can check its definition online, it is pretty
# much ASCII-specific.
print(string.punctuation)
# The same holds for string.whitespaces.
