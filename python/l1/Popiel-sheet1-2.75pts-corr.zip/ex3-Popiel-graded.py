import math


def digits(n):
    return (int(math.log10(n))+1)
def adjust(n,width):
    return ((width-digits(n))*" "+str(n))

def mult_table(x1,x2,y1,y2):
    width=digits(x2*y2)
    line=width*" "
    for i in range(x1,x2+1):
        line+=" "+adjust(i,width)
    print(line)
    
    for y in range (y1,y2+1):
        line=adjust(y,width)
        for x in range (x1,x2+1):
            number=y*x
            prefix=(width-digits(i)+1)*" "
            line+=" "+adjust(number,width)
        print(line)    
            


mult_table(3,5,2,4)

# Grade: 1.75

# Didactic notes:
# Please next time, include a few more tests. (There is little point in doing some final discussion here, and
# I get that, but it's good to do a few more tests, one can e.g. try the negative numbers too.)
mult_table(95, 120, 60, 100)  # passes
mult_table(3, 5, 2, 4)  # passes
mult_table(1, 1, 1, 1)  # passes
mult_table(-10, 15, -15, 15)  # does not pass / crashes (it would be okay that this one did not)
